package com.example.helloworld;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText yourName;
    private TextView outputName;
    private EditText name_p;
    private TextView outputp;

    public void printHello(View v) {
        Button helloButton = (Button) v;
        ((Button) v).setText("You clicked me!");
        yourName = (EditText) findViewById(R.id.inputText);
        outputName = (TextView) findViewById(R.id.outputText);
        outputName.setText("Hello, " + yourName.getText());
        outputName.setVisibility(View.VISIBLE);
    }
    public void printBye(View p) {
        Button byeButton = (Button) p;
        ((Button) p).setText("You clicked me!");
        name_p = (EditText) findViewById(R.id.inputText);
        outputp = (TextView) findViewById(R.id.outputText);
        outputp.setText("Goodbye, " + name_p.getText());
        outputp.setVisibility(View.VISIBLE);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}